FoldFlow Plugin Installation Instructions:
--------------------------------------------------
1. Close 3ds Max.
2. Copy the file 'FoldFlow_Free_2024.dlm' into your 3ds Max Plugins folder:
   e.g. C:\Program Files\Autodesk\3ds Max 2024\Plugins\
3. Start 3ds Max.
4. Apply the 'Lab' modifier to any geometry to start using FoldFlow.
